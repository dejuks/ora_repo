// pages/ebook/EbookSubmissionCreatePage.jsx
import React, { useMemo, useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import MainLayout from "../../components/layout/MainLayout.jsx";
import ebookApi from "../../api/ebook.api.js";

const currentYear = new Date().getFullYear();
const blankForm = {
  title: "",
  abstract: "",
  keywords: "",
  language: "English",
};

const allowedExtensions = ["pdf", "doc", "docx", "epub", "zip", "txt"];

function keywordList(value) {
  return String(value || "")
    .split(",")
    .map((item) => item.trim())
    .filter(Boolean);
}

export default function EbookSubmissionCreatePage() {
  const navigate = useNavigate();
  const [form, setForm] = useState(blankForm);
  const [manuscriptFile, setManuscriptFile] = useState(null);
  const [saving, setSaving] = useState(false);
  const [serverError, setServerError] = useState("");
  const [touched, setTouched] = useState({});

  const validations = useMemo(() => {
    const errors = {};
    const keywords = keywordList(form.keywords);
    const fileExt = manuscriptFile?.name?.split(".")?.pop()?.toLowerCase();

    if (!form.title.trim()) errors.title = "Title is required.";
    else if (form.title.trim().length < 8) errors.title = "Title should be at least 8 characters.";

    if (!form.abstract.trim()) errors.abstract = "Abstract is required.";
    else if (form.abstract.trim().length < 80) errors.abstract = "Abstract should be at least 80 characters.";

    if (!keywords.length) errors.keywords = "Add at least 3 keywords separated by commas.";
    else if (keywords.length < 3) errors.keywords = "Please provide at least 3 keywords.";

    if (!form.language.trim()) errors.language = "Language is required.";

    if (!manuscriptFile) errors.file = "Please upload the manuscript file.";
    else if (fileExt && !allowedExtensions.includes(fileExt)) {
      errors.file = `Allowed file types: ${allowedExtensions.join(", ")}.`;
    }

    return errors;
  }, [form, manuscriptFile]);

  const submissionChecklist = [
    { label: "Title added", done: !!form.title.trim() },
    { label: "Abstract completed", done: form.abstract.trim().length >= 80 },
    { label: "At least 3 keywords", done: keywordList(form.keywords).length >= 3 },
    { label: "Language selected", done: !!form.language.trim() },
    { label: "Manuscript file attached", done: !!manuscriptFile },
  ];

  const isValid = Object.keys(validations).length === 0;

  const setField = (key, value) => {
    setForm((prev) => ({ ...prev, [key]: value }));
    setTouched((prev) => ({ ...prev, [key]: true }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setTouched({ 
      title: true, 
      abstract: true, 
      keywords: true, 
      language: true, 
      file: true 
    });
    setServerError("");

    if (!isValid) return;

    setSaving(true);
    try {
      // Prepare submission data
      const submissionData = {
        ...form,
        keywords: keywordList(form.keywords).join(", "),
        file: manuscriptFile,
        file_role: "manuscript",
      };

      // Use the createSubmission method from ebookApi
      // This will automatically handle FormData for file uploads
      const created = await ebookApi.createSubmission(submissionData);

      // Navigate to the submission detail page
      // The API returns submission_id in the response
      if (created && created.submission_id) {
        navigate(`/ebook/submissions/${created.submission_id}`);
      } else if (created && created.id) {
        navigate(`/ebook/submissions/${created.id}`);
      } else {
        // If we can't determine the ID, go to my submissions list
        navigate("/ebook/my-submissions");
      }
    } catch (err) {
      console.error("Submission error:", err);
      
      // Handle specific error cases
      if (err?.response?.status === 401) {
        setServerError("Your session has expired. Please login again.");
        // Optionally redirect to login
        setTimeout(() => navigate("/login"), 2000);
      } else if (err?.response?.status === 413) {
        setServerError("File is too large. Please check the file size limits.");
      } else {
        setServerError(
          err?.response?.data?.message || 
          err?.message || 
          "Failed to create submission. Please try again."
        );
      }
    } finally {
      setSaving(false);
    }
  };

  const feedback = (key) => touched[key] && validations[key] ? 
    <div className="invalid-feedback d-block">{validations[key]}</div> : null;

  return (
    <MainLayout>
      <section className="content-header mb-3 d-flex justify-content-between align-items-center flex-wrap">
        <div>
          <h1 className="mb-1">Submit New eBook</h1>
          <p className="text-muted mb-0">
            Fill in the details below to submit your manuscript. 
            After submission, it will go through editorial screening.
          </p>
        </div>
        <Link className="btn btn-outline-secondary" to="/ebook/my-submissions">
          <i className="fas fa-arrow-left mr-1"></i> Back to my submissions
        </Link>
      </section>

      {serverError ? (
        <div className="alert alert-danger alert-dismissible fade show" role="alert">
          <i className="fas fa-exclamation-circle mr-2"></i>
          {serverError}
          <button 
            type="button" 
            className="close" 
            onClick={() => setServerError("")}
            aria-label="Close"
          >
            <span aria-hidden="true">&times;</span>
          </button>
        </div>
      ) : null}

      <div className="row">
        <div className="col-lg-8">
          <div className="card card-primary card-outline">
            <form onSubmit={handleSubmit} noValidate>
              <div className="card-header">
                <h3 className="card-title mb-0">
                  <i className="fas fa-pen-alt mr-2"></i>
                  Submission Form
                </h3>
              </div>
              <div className="card-body">
                <div className="form-group">
                  <label>
                    Title <span className="text-danger">*</span>
                  </label>
                  <input 
                    className={`form-control ${touched.title && validations.title ? "is-invalid" : ""}`} 
                    value={form.title} 
                    onChange={(e) => setField("title", e.target.value)} 
                    onBlur={() => setTouched((prev) => ({ ...prev, title: true }))} 
                    placeholder="Enter the book title"
                  />
                  {feedback("title")}
                </div>

                <div className="form-group">
                  <label>
                    Abstract <span className="text-danger">*</span>
                  </label>
                  <textarea 
                    rows="6" 
                    className={`form-control ${touched.abstract && validations.abstract ? "is-invalid" : ""}`} 
                    value={form.abstract} 
                    onChange={(e) => setField("abstract", e.target.value)} 
                    onBlur={() => setTouched((prev) => ({ ...prev, abstract: true }))} 
                    placeholder="Provide a clear summary of the manuscript. Include the main objectives, methods, and conclusions."
                  />
                  <div className="d-flex justify-content-between mt-1">
                    <small className="text-muted">
                      <i className="fas fa-info-circle mr-1"></i>
                      Recommended: 120–350 words.
                    </small>
                    <small className={form.abstract.trim().length < 80 ? "text-warning" : "text-success"}>
                      <i className="fas fa-text-height mr-1"></i>
                      {form.abstract.trim().length} characters
                    </small>
                  </div>
                  {feedback("abstract")}
                </div>

                <div className="form-group">
                  <label>
                    Keywords <span className="text-danger">*</span>
                  </label>
                  <input 
                    className={`form-control ${touched.keywords && validations.keywords ? "is-invalid" : ""}`} 
                    value={form.keywords} 
                    onChange={(e) => setField("keywords", e.target.value)} 
                    onBlur={() => setTouched((prev) => ({ ...prev, keywords: true }))} 
                    placeholder="Example: digital publishing, repository, ORA"
                  />
                  <small className="text-muted">
                    <i className="fas fa-tags mr-1"></i>
                    Separate keywords with commas. At least 3 keywords required.
                  </small>
                  {feedback("keywords")}
                </div>

                <div className="form-group">
                  <label>
                    Language <span className="text-danger">*</span>
                  </label>
                  <input 
                    className={`form-control ${touched.language && validations.language ? "is-invalid" : ""}`} 
                    value={form.language} 
                    onChange={(e) => setField("language", e.target.value)} 
                    onBlur={() => setTouched((prev) => ({ ...prev, language: true }))} 
                    placeholder="e.g., English, Oromo, Amharic"
                  />
                  {feedback("language")}
                </div>

                <div className="form-group">
                  <label>
                    Manuscript File <span className="text-danger">*</span>
                  </label>
                  <div className="custom-file">
                    <input 
                      type="file" 
                      className={`custom-file-input ${touched.file && validations.file ? "is-invalid" : ""}`}
                      id="manuscriptFile"
                      accept=".pdf,.doc,.docx,.epub,.zip,.txt" 
                      onChange={(e) => { 
                        setManuscriptFile(e.target.files?.[0] || null); 
                        setTouched((prev) => ({ ...prev, file: true })); 
                      }} 
                    />
                    <label className="custom-file-label" htmlFor="manuscriptFile">
                      {manuscriptFile ? manuscriptFile.name : "Choose file..."}
                    </label>
                  </div>
                  <small className="text-muted d-block mt-2">
                    <i className="fas fa-file mr-1"></i>
                    Supported formats: PDF, DOC, DOCX, EPUB, ZIP, TXT. 
                    Maximum size: 10MB for manuscripts.
                  </small>
                  {manuscriptFile ? (
                    <div className="mt-2 text-success">
                      <i className="fas fa-check-circle mr-1"></i>
                      Selected file: <strong>{manuscriptFile.name}</strong> 
                      ({(manuscriptFile.size / 1024 / 1024).toFixed(2)} MB)
                    </div>
                  ) : null}
                  {feedback("file")}
                </div>
              </div>
              <div className="card-footer d-flex justify-content-between align-items-center flex-wrap" style={{ gap: 12 }}>
                <div className="text-muted">
                  <i className="fas fa-save mr-1"></i>
                  This will create a draft submission. You can submit it for review after saving.
                </div>
                <button 
                  className="btn btn-primary" 
                  disabled={saving || !isValid}
                  type="submit"
                >
                  {saving ? (
                    <>
                      <span className="spinner-border spinner-border-sm mr-2" role="status" aria-hidden="true"></span>
                      Saving draft...
                    </>
                  ) : (
                    <>
                      <i className="fas fa-save mr-2"></i>
                      Save Draft
                    </>
                  )}
                </button>
              </div>
            </form>
          </div>
        </div>

        <div className="col-lg-4">
          <div className="card card-outline card-success">
            <div className="card-header">
              <h3 className="card-title mb-0">
                <i className="fas fa-check-circle mr-2"></i>
                Readiness Checklist
              </h3>
            </div>
            <div className="card-body">
              <ul className="list-unstyled mb-3">
                {submissionChecklist.map((item) => (
                  <li key={item.label} className="mb-2 d-flex justify-content-between align-items-center">
                    <span>
                      {item.done ? (
                        <i className="fas fa-check-circle text-success mr-2"></i>
                      ) : (
                        <i className="fas fa-circle text-secondary mr-2" style={{ fontSize: "0.5rem", verticalAlign: "middle" }}></i>
                      )}
                      {item.label}
                    </span>
                    <span className={`badge badge-${item.done ? "success" : "secondary"}`}>
                      {item.done ? "Ready" : "Pending"}
                    </span>
                  </li>
                ))}
              </ul>
              <div className="alert alert-light border mb-0">
                <strong>
                  <i className="fas fa-lightbulb mr-2"></i>
                  Before you submit
                </strong>
                <ul className="mb-0 mt-2 pl-3">
                  <li>Use the final manuscript version</li>
                  <li>Keep keywords specific and searchable</li>
                  <li>Ensure abstract is clear and comprehensive</li>
                  <li>Check file format and size</li>
                </ul>
              </div>
            </div>
          </div>

          <div className="card card-outline card-info">
            <div className="card-header">
              <h3 className="card-title mb-0">
                <i className="fas fa-tasks mr-2"></i>
                Submission Workflow
              </h3>
            </div>
            <div className="card-body">
              <ol className="pl-3 mb-0">
                <li className="mb-2">
                  <strong className="text-success">Draft Creation</strong>
                  <br />
                  <small className="text-muted">You are here</small>
                </li>
                <li className="mb-2">
                  <strong>Editorial Screening</strong>
                  <br />
                  <small className="text-muted">Initial quality check</small>
                </li>
                <li className="mb-2">
                  <strong>Peer Review</strong>
                  <br />
                  <small className="text-muted">Expert evaluation</small>
                </li>
                <li className="mb-2">
                  <strong>Decision & Revisions</strong>
                  <br />
                  <small className="text-muted">Author revisions if needed</small>
                </li>
                <li className="mb-2">
                  <strong>Production</strong>
                  <br />
                  <small className="text-muted">Final formatting</small>
                </li>
                <li>
                  <strong>Publication</strong>
                  <br />
                  <small className="text-muted">Live on platform</small>
                </li>
              </ol>
            </div>
          </div>

          <div className="card card-outline card-warning">
            <div className="card-header">
              <h3 className="card-title mb-0">
                <i className="fas fa-question-circle mr-2"></i>
                Need Help?
              </h3>
            </div>
            <div className="card-body">
              <p className="mb-2">
                <i className="fas fa-envelope text-warning mr-2"></i>
                <a href="mailto:ebooks@oraresearcher.org">ebooks@oraresearcher.org</a>
              </p>
              <p className="mb-0">
                <i className="fas fa-file-alt text-warning mr-2"></i>
                <a href="/author-guidelines" target="_blank">Author Guidelines</a>
              </p>
            </div>
          </div>
        </div>
      </div>
    </MainLayout>
  );
}