// pages/ebook/EbookAuthorStageListPage.jsx
import React, { useEffect, useMemo, useState } from "react";
import { Link } from "react-router-dom";
import MainLayout from "../../components/layout/MainLayout.jsx";
import ebookApi from "../../api/ebook.api";
import StatusBadge from "./components/StatusBadge.jsx";

const STAGE_CONFIG = {
  all: {
    heading: "My Submissions",
    subtitle:
      "List of all your submissions, including drafts. Open a submission to continue editing or review workflow details.",
    empty: "You have no submissions yet.",
    query: {},
    icon: "fa-list",
    color: "primary"
  },
  drafts: {
    heading: "My Drafts",
    subtitle: "Continue unfinished submissions.",
    empty: "You have no draft submissions.",
    query: { status: "draft" },
    icon: "fa-pen",
    color: "secondary"
  },
  revisions: {
    heading: "Revision Requests",
    subtitle: "Editor-requested revisions only.",
    empty: "No submissions are waiting for revision.",
    query: { stage: "revisions" },
    icon: "fa-code-branch",
    color: "warning"
  },
  payments: {
    heading: "Payments & Waivers",
    subtitle: "Submissions waiting for payment.",
    empty: "No submissions need payment.",
    query: { stage: "payments" },
    icon: "fa-credit-card",
    color: "danger"
  },
  proofs: {
    heading: "Proof Approvals",
    subtitle: "Approve final proofs.",
    empty: "No submissions need proof approval.",
    query: { stage: "proofs" },
    icon: "fa-check-circle",
    color: "success"
  },
  rejected: {
    heading: "Rejected by Editor",
    subtitle: "Submissions closed by editorial decision.",
    empty: "No submissions have been rejected by the editor.",
    query: { status: "rejected" },
    icon: "fa-times-circle",
    color: "dark"
  },
};

const PAGE_SIZE_OPTIONS = [10, 25, 50, 100];

function formatDate(value) {
  if (!value) return "—";
  try {
    const date = new Date(value);
    return date.toLocaleDateString() + ' ' + date.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
  } catch {
    return value;
  }
}

function getPrimaryAction(stage, row) {
  if (stage === "drafts") {
    return {
      label: "Continue Draft",
      className: "btn btn-primary",
      to: `/ebook/submissions/${row.submission_id}`,
    };
  }
  if (stage === "revisions") {
    return {
      label: "Open Revision",
      className: "btn btn-warning",
      to: `/ebook/submissions/${row.submission_id}/review-comments`,
    };
  }
  if (stage === "payments") {
    return {
      label: "Open Payment",
      className: "btn btn-danger",
      to: `/ebook/submissions/${row.submission_id}/payment`,
    };
  }
  if (stage === "proofs") {
    return {
      label: "Open Proof",
      className: "btn btn-success",
      to: `/ebook/submissions/${row.submission_id}/proof-approval`,
    };
  }
  return {
    label: "Open Detail",
    className: "btn btn-outline-primary",
    to: `/ebook/submissions/${row.submission_id}`,
  };
}

// Beautiful Modal Component
const SubmissionModal = ({ isOpen, onClose, submission, stage }) => {
  if (!isOpen || !submission) return null;

  const primaryAction = getPrimaryAction(stage, submission);

  return (
    <>
      <div className="modal fade show d-block" tabIndex="-1" role="dialog" style={{ display: 'block' }}>
        <div className="modal-dialog modal-lg modal-dialog-centered modal-dialog-scrollable" role="document">
          <div className="modal-content border-0 shadow-lg" style={{ borderRadius: '16px', overflow: 'hidden' }}>
            <div className="modal-header border-0 bg-gradient-primary text-white" style={{ 
              background: 'linear-gradient(135deg, #667eea 0%, #764ba2 100%)',
              padding: '1.5rem 1.5rem'
            }}>
              <h5 className="modal-title h4 font-weight-bold">
                <i className="fas fa-file-alt mr-2"></i>
                Submission Details
              </h5>
              <button 
                type="button" 
                className="close text-white" 
                onClick={onClose}
                style={{ opacity: 0.8, textShadow: 'none' }}
              >
                <span className="h3">&times;</span>
              </button>
            </div>

            <div className="modal-body p-4">
              <div className="row">
                <div className="col-md-6 mb-3">
                  <div className="info-card p-3 bg-light rounded-lg">
                    <small className="text-muted d-block mb-1">Title</small>
                    <h6 className="font-weight-bold mb-0">{submission.title || '—'}</h6>
                  </div>
                </div>
                <div className="col-md-6 mb-3">
                  <div className="info-card p-3 bg-light rounded-lg">
                    <small className="text-muted d-block mb-1">Subtitle</small>
                    <h6 className="mb-0">{submission.subtitle || '—'}</h6>
                  </div>
                </div>
                
                <div className="col-md-4 mb-3">
                  <div className="info-card p-3 bg-light rounded-lg">
                    <small className="text-muted d-block mb-1">Status</small>
                    <StatusBadge value={submission.status} />
                  </div>
                </div>
                
                <div className="col-md-4 mb-3">
                  <div className="info-card p-3 bg-light rounded-lg">
                    <small className="text-muted d-block mb-1">Category</small>
                    <span className="font-weight-bold">{submission.category || '—'}</span>
                  </div>
                </div>
                
                <div className="col-md-4 mb-3">
                  <div className="info-card p-3 bg-light rounded-lg">
                    <small className="text-muted d-block mb-1">Language</small>
                    <span className="font-weight-bold">{submission.language || '—'}</span>
                  </div>
                </div>

                <div className="col-md-6 mb-3">
                  <div className="info-card p-3 bg-light rounded-lg">
                    <small className="text-muted d-block mb-1">Payment Status</small>
                    {submission.payment_status ? (
                      <>
                        <StatusBadge value={submission.payment_status} />
                        <div className="mt-1">
                          <span className="font-weight-bold">
                            {submission.amount_due || 0} {submission.currency_code || "ETB"}
                          </span>
                        </div>
                      </>
                    ) : (
                      <span className="text-muted">—</span>
                    )}
                  </div>
                </div>

                <div className="col-md-6 mb-3">
                  <div className="info-card p-3 bg-light rounded-lg">
                    <small className="text-muted d-block mb-1">Proof Status</small>
                    {submission.proof_sent_to_author ? (
                      <>
                        <StatusBadge value={submission.author_proof_approved ? "approved" : "pending"} />
                        <div className="mt-1">
                          <span className="text-muted">
                            {submission.author_proof_approved ? "Approved by author" : "Waiting for author"}
                          </span>
                        </div>
                      </>
                    ) : (
                      <span className="text-muted">Not ready</span>
                    )}
                  </div>
                </div>

                <div className="col-md-6 mb-3">
                  <div className="info-card p-3 bg-light rounded-lg">
                    <small className="text-muted d-block mb-1">Files</small>
                    <div className="d-flex align-items-center">
                      <span className="h5 mb-0 mr-2 font-weight-bold">{submission.file_count || 0}</span>
                      {Array.isArray(submission.file_roles) && submission.file_roles.length > 0 && (
                        <span className="text-muted small">
                          ({submission.file_roles.join(", ")})
                        </span>
                      )}
                    </div>
                  </div>
                </div>

                <div className="col-md-6 mb-3">
                  <div className="info-card p-3 bg-light rounded-lg">
                    <small className="text-muted d-block mb-1">Last Updated</small>
                    <span className="font-weight-bold">
                      {formatDate(submission.updated_at || submission.submitted_at || submission.accepted_at)}
                    </span>
                  </div>
                </div>

                {submission.abstract && (
                  <div className="col-12 mb-3">
                    <div className="info-card p-3 bg-light rounded-lg">
                      <small className="text-muted d-block mb-1">Abstract</small>
                      <p className="mb-0" style={{ lineHeight: 1.6 }}>{submission.abstract}</p>
                    </div>
                  </div>
                )}

                {submission.keywords && (
                  <div className="col-12 mb-3">
                    <div className="info-card p-3 bg-light rounded-lg">
                      <small className="text-muted d-block mb-1">Keywords</small>
                      <div>
                        {Array.isArray(submission.keywords) 
                          ? submission.keywords.map((keyword, i) => (
                              <span key={i} className="badge badge-light mr-2 mb-2 px-3 py-2">
                                {keyword}
                              </span>
                            ))
                          : submission.keywords?.split(',').map((keyword, i) => (
                              <span key={i} className="badge badge-light mr-2 mb-2 px-3 py-2">
                                {keyword.trim()}
                              </span>
                            ))}
                      </div>
                    </div>
                  </div>
                )}
              </div>
            </div>

            <div className="modal-footer border-0 bg-light">
              <button
                type="button"
                className="btn btn-secondary px-4 rounded-pill"
                onClick={onClose}
              >
                <i className="fas fa-times mr-2"></i>
                Close
              </button>

              <div className="d-flex" style={{ gap: 8 }}>
                <Link
                  className="btn btn-outline-primary rounded-pill px-4"
                  to={`/ebook/submissions/${submission.submission_id}`}
                >
                  <i className="fas fa-eye mr-2"></i>
                  View Detail
                </Link>

                {primaryAction && (
                  <Link
                    className={`${primaryAction.className} rounded-pill px-4`}
                    to={primaryAction.to}
                  >
                    <i className="fas fa-arrow-right mr-2"></i>
                    {primaryAction.label}
                  </Link>
                )}
              </div>
            </div>
          </div>
        </div>
      </div>
      <div className="modal-backdrop fade show" style={{ 
        position: 'fixed', 
        top: 0, 
        left: 0, 
        width: '100%', 
        height: '100%', 
        backgroundColor: 'rgba(0,0,0,0.5)', 
        zIndex: 1040,
        backdropFilter: 'blur(4px)'
      }}></div>
    </>
  );
};

export default function EbookAuthorStageListPage({ stage = "all" }) {
  const config = STAGE_CONFIG[stage] || STAGE_CONFIG.all;

  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [serverSearch, setServerSearch] = useState("");
  const [searchInput, setSearchInput] = useState("");
  const [rows, setRows] = useState([]);

  const [sortBy, setSortBy] = useState("updated_at");
  const [sortDir, setSortDir] = useState("desc");
  const [pageSize, setPageSize] = useState(10);
  const [page, setPage] = useState(1);

  const [selectedSubmission, setSelectedSubmission] = useState(null);

  const load = async (query = "") => {
    setLoading(true);
    setError("");
    try {
      const result = await ebookApi.listMySubmissions({
        limit: 100,
        search: query,
        ...(config.query || {}),
      });
      setRows(Array.isArray(result?.rows) ? result.rows : []);
      setPage(1);
    } catch (err) {
      console.error("Load error:", err);
      setError(err?.response?.data?.message || err?.message || "Failed to load submissions.");
      setRows([]);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    load("");
    setSearchInput("");
    setServerSearch("");
  }, [stage]);

  const handleSearch = (e) => {
    e.preventDefault();
    setServerSearch(searchInput);
    load(searchInput);
    setPage(1);
  };

  const handleSort = (column) => {
    if (sortBy === column) {
      setSortDir((prev) => (prev === "asc" ? "desc" : "asc"));
    } else {
      setSortBy(column);
      setSortDir("asc");
    }
    setPage(1);
  };

  const sortedRows = useMemo(() => {
    const list = [...rows];
    list.sort((a, b) => {
      const aVal = a?.[sortBy];
      const bVal = b?.[sortBy];

      if (sortBy === "title" || sortBy === "status" || sortBy === "payment_status") {
        const aa = String(aVal || "").toLowerCase();
        const bb = String(bVal || "").toLowerCase();
        if (aa < bb) return sortDir === "asc" ? -1 : 1;
        if (aa > bb) return sortDir === "asc" ? 1 : -1;
        return 0;
      }

      if (sortBy === "file_count" || sortBy === "amount_due") {
        const aa = Number(aVal || 0);
        const bb = Number(bVal || 0);
        return sortDir === "asc" ? aa - bb : bb - aa;
      }

      const aa = aVal ? new Date(aVal).getTime() : 0;
      const bb = bVal ? new Date(bVal).getTime() : 0;
      return sortDir === "asc" ? aa - bb : bb - aa;
    });
    return list;
  }, [rows, sortBy, sortDir]);

  const totalPages = Math.max(1, Math.ceil(sortedRows.length / pageSize));
  const currentPage = Math.min(page, totalPages);

  const paginatedRows = useMemo(() => {
    const start = (currentPage - 1) * pageSize;
    return sortedRows.slice(start, start + pageSize);
  }, [sortedRows, currentPage, pageSize]);

  const sortIcon = (column) => {
    if (sortBy !== column) return <i className="fas fa-sort text-muted ml-1"></i>;
    return sortDir === "asc" 
      ? <i className="fas fa-sort-up text-primary ml-1"></i>
      : <i className="fas fa-sort-down text-primary ml-1"></i>;
  };

  const clearSearch = () => {
    setSearchInput("");
    setServerSearch("");
    load("");
  };

  return (
    <MainLayout>
      {/* Header Section */}
      <section className="content-header mb-4">
        <div className="d-flex justify-content-between align-items-center flex-wrap">
          <div>
            <h1 className="display-5 mb-2 font-weight-bold" style={{ color: '#2d3748' }}>
              <i className={`fas ${config.icon} text-${config.color} mr-3`}></i>
              {config.heading}
            </h1>
            <p className="text-muted mb-0">{config.subtitle}</p>
          </div>
          <Link 
            className="btn btn-primary btn-lg rounded-pill px-4 shadow-sm" 
            to="/ebook/submissions/create"
          >
            <i className="fas fa-plus mr-2"></i>
            New Submission
          </Link>
        </div>
      </section>

      {/* Error Alert */}
      {error && (
        <div className="alert alert-danger alert-dismissible fade show rounded-lg shadow-sm mb-4" role="alert">
          <div className="d-flex align-items-center">
            <i className="fas fa-exclamation-circle mr-3 fa-lg"></i>
            <div className="flex-grow-1">{error}</div>
            <button type="button" className="close" onClick={() => setError("")}>
              <span>&times;</span>
            </button>
          </div>
        </div>
      )}

      {/* Main Card */}
      <div className="card border-0 shadow-sm" style={{ borderRadius: '16px', overflow: 'hidden' }}>
        {/* Search Header */}
        <div className="card-header bg-white border-0 py-3 px-4">
          <form className="d-flex justify-content-between align-items-center flex-wrap" onSubmit={handleSearch} style={{ gap: 12 }}>
            <div className="d-flex align-items-center" style={{ gap: 8 }}>
              <div className="input-group" style={{ minWidth: 320 }}>
                <div className="input-group-prepend">
                  <span className="input-group-text bg-white border-right-0">
                    <i className="fas fa-search text-muted"></i>
                  </span>
                </div>
                <input
                  className="form-control border-left-0 rounded-right"
                  placeholder="Search by title, abstract, or keywords..."
                  value={searchInput}
                  onChange={(e) => setSearchInput(e.target.value)}
                />
              </div>
              <button className="btn btn-primary rounded-pill px-4" type="submit">
                Search
              </button>
              {serverSearch && (
                <button className="btn btn-outline-secondary rounded-pill px-3" type="button" onClick={clearSearch}>
                  <i className="fas fa-times mr-1"></i>
                  Clear
                </button>
              )}
            </div>
          </form>
        </div>

        {/* Table Controls */}
        <div className="card-body bg-light border-bottom py-3 px-4">
          <div className="d-flex justify-content-between align-items-center flex-wrap" style={{ gap: 12 }}>
            <div className="text-muted">
              <i className="fas fa-database mr-2"></i>
              Showing {rows.length ? (currentPage - 1) * pageSize + 1 : 0}–
              {Math.min(currentPage * pageSize, sortedRows.length)} of {sortedRows.length}
              {serverSearch && (
                <>
                  {" "}results for "<span className="font-weight-bold text-primary">{serverSearch}</span>"
                </>
              )}
            </div>

            <div className="d-flex align-items-center" style={{ gap: 16 }}>
              <div className="d-flex align-items-center">
                <span className="small text-muted mr-2">Rows per page:</span>
                <select
                  className="form-control form-control-sm rounded-pill"
                  style={{ width: 90 }}
                  value={pageSize}
                  onChange={(e) => {
                    setPageSize(Number(e.target.value));
                    setPage(1);
                  }}
                >
                  {PAGE_SIZE_OPTIONS.map((size) => (
                    <option key={size} value={size}>
                      {size}
                    </option>
                  ))}
                </select>
              </div>
            </div>
          </div>
        </div>

        {/* Table */}
        <div className="table-responsive">
          <table className="table table-hover mb-0">
            <thead className="bg-light">
              <tr>
                <th 
                  className="cursor-pointer py-3" 
                  style={{ cursor: "pointer" }} 
                  onClick={() => handleSort("title")}
                >
                  Title {sortIcon("title")}
                </th>
                <th 
                  className="cursor-pointer py-3" 
                  style={{ cursor: "pointer", width: 140 }} 
                  onClick={() => handleSort("status")}
                >
                  Status {sortIcon("status")}
                </th>
                <th 
                  className="cursor-pointer py-3" 
                  style={{ cursor: "pointer", width: 170 }} 
                  onClick={() => handleSort("payment_status")}
                >
                  Payment {sortIcon("payment_status")}
                </th>
                <th className="py-3" style={{ width: 140 }}>Proof</th>
                <th 
                  className="cursor-pointer py-3" 
                  style={{ cursor: "pointer", width: 120 }} 
                  onClick={() => handleSort("file_count")}
                >
                  Files {sortIcon("file_count")}
                </th>
                <th 
                  className="cursor-pointer py-3" 
                  style={{ cursor: "pointer", width: 160 }} 
                  onClick={() => handleSort("updated_at")}
                >
                  Last Updated {sortIcon("updated_at")}
                </th>
                <th className="py-3" style={{ width: 100 }}>Action</th>
              </tr>
            </thead>
            <tbody>
              {loading ? (
                <tr>
                  <td colSpan="7" className="text-center py-5">
                    <div className="d-flex align-items-center justify-content-center">
                      <div className="spinner-border text-primary mr-3" role="status">
                        <span className="sr-only">Loading...</span>
                      </div>
                      <span className="text-muted">Loading submissions...</span>
                    </div>
                  </td>
                </tr>
              ) : !paginatedRows.length ? (
                <tr>
                  <td colSpan="7" className="text-center py-5">
                    <div className="empty-state">
                      <i className={`fas ${config.icon} fa-3x text-muted mb-3`}></i>
                      <h6 className="mb-2">{config.empty}</h6>
                      {stage === "all" && (
                        <Link to="/ebook/submissions/create" className="btn btn-primary btn-sm rounded-pill mt-2">
                          <i className="fas fa-plus mr-2"></i>
                          Create Your First Submission
                        </Link>
                      )}
                    </div>
                  </td>
                </tr>
              ) : (
                paginatedRows.map((row) => (
                  <tr 
                    key={row.submission_id} 
                    className="cursor-pointer"
                    style={{ cursor: 'pointer' }}
                    onClick={() => setSelectedSubmission(row)}
                  >
                    <td className="align-middle">
                      <div className="font-weight-bold">{row.title || 'Untitled'}</div>
                      <small className="text-muted">
                        <i className="fas fa-tag mr-1"></i>
                        {row.category || "No category"} • <i className="fas fa-language mr-1"></i>
                        {row.language || "—"}
                      </small>
                    </td>

                    <td className="align-middle">
                      <StatusBadge value={row.status} />
                    </td>

                    <td className="align-middle">
                      {row.amount_due || row.payment_status ? (
                        <>
                          <StatusBadge value={row.payment_status || "pending"} />
                          <small className="d-block text-muted mt-1">
                            {row.amount_due || 0} {row.currency_code || "ETB"}
                          </small>
                        </>
                      ) : (
                        <span className="text-muted">—</span>
                      )}
                    </td>

                    <td className="align-middle">
                      {row.proof_sent_to_author ? (
                        <>
                          <StatusBadge
                            value={row.author_proof_approved ? "approved" : "pending"}
                          />
                          <small className="d-block text-muted mt-1">
                            {row.author_proof_approved ? "Approved" : "Waiting"}
                          </small>
                        </>
                      ) : (
                        <span className="text-muted">Not ready</span>
                      )}
                    </td>

                    <td className="align-middle">
                      <div className="d-flex align-items-center">
                        <span className="badge badge-light mr-2">{row.file_count || 0}</span>
                        {Array.isArray(row.file_roles) && row.file_roles.length > 0 && (
                          <small className="text-muted text-truncate" style={{ maxWidth: 120 }}>
                            {row.file_roles.join(", ")}
                          </small>
                        )}
                      </div>
                    </td>

                    <td className="align-middle">
                      <div className="small">
                        <i className="far fa-clock text-muted mr-1"></i>
                        {formatDate(row.updated_at || row.submitted_at || row.accepted_at)}
                      </div>
                    </td>

                    <td className="align-middle">
                      <button
                        type="button"
                        className="btn btn-sm btn-outline-primary rounded-pill px-3"
                        onClick={(e) => {
                          e.stopPropagation();
                          setSelectedSubmission(row);
                        }}
                      >
                        <i className="fas fa-eye mr-1"></i>
                        View
                      </button>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>

        {/* Pagination Footer */}
        <div className="card-footer bg-white border-0 py-3 px-4">
          <div className="d-flex justify-content-between align-items-center flex-wrap" style={{ gap: 12 }}>
            <div className="small text-muted">
              Page {currentPage} of {totalPages}
            </div>

            <div className="btn-group">
              <button
                type="button"
                className="btn btn-outline-secondary rounded-pill px-4 mr-2"
                disabled={currentPage <= 1}
                onClick={() => setPage((p) => Math.max(1, p - 1))}
              >
                <i className="fas fa-chevron-left mr-2"></i>
                Previous
              </button>
              <button
                type="button"
                className="btn btn-outline-secondary rounded-pill px-4"
                disabled={currentPage >= totalPages}
                onClick={() => setPage((p) => Math.min(totalPages, p + 1))}
              >
                Next
                <i className="fas fa-chevron-right ml-2"></i>
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* Submission Detail Modal */}
      <SubmissionModal 
        isOpen={!!selectedSubmission}
        onClose={() => setSelectedSubmission(null)}
        submission={selectedSubmission}
        stage={stage}
      />
    </MainLayout>
  );
}