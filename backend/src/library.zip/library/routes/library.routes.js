import express from 'express';
import { authenticate } from '../../middleware/auth.middleware.js';
import physicalLibraryRoutes from './physicalLibrary.routes.js';
import digitalLibraryRoutes from './digitalLibrary.routes.js';

const router = express.Router();
router.use(authenticate);
router.use('/physical-library', physicalLibraryRoutes);
router.use('/digital-library', digitalLibraryRoutes);
export default router;
